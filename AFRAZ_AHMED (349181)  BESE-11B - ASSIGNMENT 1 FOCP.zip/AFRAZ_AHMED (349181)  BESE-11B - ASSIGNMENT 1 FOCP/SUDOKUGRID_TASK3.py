Python 3.9.0 (tags/v3.9.0:9cf6752, Oct  5 2020, 15:34:40) [MSC v.1927 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>>    # CREATING_SUDOKU_GRID

import math
sudokuGrid = [  [0,0,0,1],  [0,2,0,0],  [0,0,4,0],  [3,0,0,0]  ]
size = len(sudokuGrid)
print("Sudoku grid size is ", size, " by ", size)
for row in sudokuGrid:
    print(row)

         # Defining_the_SUDOKU_AREAS

area = int(math.sqrt(size))
print ("Size of each area is: ", area, " by ",area)
target = 1

         # Searching_all_target_values_for_single_SUDOKU_AREA

for target in range(4):
    target += 1
    row = 0
    col = 0
    print("\nChecking the following area for target value: ",target)
    print("start row: ",row)
    print("end row: ",row + area - 1)
    print("start col: ",col)
    print("end col: ", col + area - 1)
    print()
    print ("Looking for ", target)
    for r in range(row, row + area):
        for c in range(col, col + area):
              print ("Checking - Row: ", r, " Column: ", c, end="")
              if (sudokuGrid[r][c] == target):
                    print (" - Target is already in area")
              else:
                    print (" - Not here")